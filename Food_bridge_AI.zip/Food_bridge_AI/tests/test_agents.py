import unittest
from datetime import datetime, timedelta

from app.agents import forecast, impact, listing, logistics, matching, safety
from app.agents.geo import haversine_km

NOW = datetime(2026, 10, 14, 14, 0)


class ListingAgentTests(unittest.TestCase):
    def test_kg_and_hours_ago(self):
        r = listing.run("20 kg cooked rice and dal prepared 1 hour ago", NOW)
        self.assertEqual(r["category"], "cooked")
        self.assertEqual(r["kg"], 20.0)
        self.assertEqual(r["meals"], 50)
        self.assertEqual(datetime.fromisoformat(r["prepared_at"]), NOW - timedelta(hours=1))

    def test_portions_and_time_of_day(self):
        r = listing.run("50 portions biryani prepared at 1 pm", NOW)
        self.assertEqual(r["meals"], 50)
        self.assertEqual(r["kg"], 20.0)
        self.assertEqual(datetime.fromisoformat(r["prepared_at"]).hour, 13)

    def test_category_detection(self):
        self.assertEqual(listing.classify_category("fresh bread and buns"), "bakery")
        self.assertEqual(listing.classify_category("sealed juice packets"), "packaged")
        self.assertEqual(listing.classify_category("milk and curd"), "dairy")

    def test_requires_quantity(self):
        with self.assertRaises(ValueError):
            listing.run("some rice", NOW)
        with self.assertRaises(ValueError):
            listing.run("   ", NOW)


class SafetyAgentTests(unittest.TestCase):
    def _listing(self, category, hours_ago):
        return {"category": category, "prepared_at": (NOW - timedelta(hours=hours_ago)).isoformat()}

    def test_fresh_cooked_is_safe(self):
        r = safety.run(self._listing("cooked", 0.5), "rice", "room", NOW)
        self.assertEqual(r["status"], "safe")

    def test_old_cooked_rejected(self):
        r = safety.run(self._listing("cooked", 3.5), "rice", "room", NOW)
        self.assertEqual(r["status"], "reject")

    def test_caution_window(self):
        r = safety.run(self._listing("cooked", 2.5), "rice", "room", NOW)
        self.assertEqual(r["status"], "caution")

    def test_plate_waste_rejected(self):
        r = safety.run(self._listing("cooked", 0), "half eaten dal", "room", NOW)
        self.assertEqual(r["status"], "reject")

    def test_chilled_extends_window(self):
        r = safety.run(self._listing("cooked", 10), "rice", "chilled", NOW)
        self.assertEqual(r["status"], "safe")

    def test_raw_meat_needs_chill(self):
        r = safety.run(self._listing("raw_meat_fish", 0), "raw chicken", "room", NOW)
        self.assertEqual(r["status"], "reject")


DONOR = {"id": 1, "name": "D", "lat": 22.30, "lng": 70.80}
NGOS = [
    {"id": 1, "name": "Near", "lat": 22.31, "lng": 70.80, "daily_need_meals": 100, "received_today": 0, "accepts": "cooked"},
    {"id": 2, "name": "Far", "lat": 22.60, "lng": 71.20, "daily_need_meals": 500, "received_today": 0, "accepts": "cooked"},
    {"id": 3, "name": "Full", "lat": 22.30, "lng": 70.81, "daily_need_meals": 50, "received_today": 50, "accepts": "cooked"},
    {"id": 4, "name": "NoCooked", "lat": 22.30, "lng": 70.81, "daily_need_meals": 50, "received_today": 0, "accepts": "bakery"},
]


class MatchingTests(unittest.TestCase):
    def test_picks_nearest_with_need(self):
        r = matching.run({"category": "cooked", "meals": 50}, DONOR, NGOS, remaining_hours=3)
        self.assertEqual(r["best"]["name"], "Near")
        names = [x["name"] for x in r["ranked"]]
        self.assertNotIn("Full", names)
        self.assertNotIn("NoCooked", names)

    def test_far_ngo_excluded_when_time_short(self):
        r = matching.run({"category": "cooked", "meals": 50}, DONOR, NGOS, remaining_hours=0.6)
        self.assertNotIn("Far", [x["name"] for x in r["ranked"]])

    def test_no_match(self):
        r = matching.run({"category": "dairy", "meals": 10}, DONOR, NGOS, remaining_hours=3)
        self.assertIsNone(r["best"])


class LogisticsTests(unittest.TestCase):
    def test_nearest_free_volunteer(self):
        vols = [
            {"id": 1, "name": "A", "lat": 22.30, "lng": 70.80, "available": 0},
            {"id": 2, "name": "B", "lat": 22.35, "lng": 70.85, "available": 1},
            {"id": 3, "name": "C", "lat": 22.50, "lng": 71.00, "available": 1},
        ]
        plan = logistics.run(DONOR, NGOS[0], vols)
        self.assertEqual(plan["volunteer_id"], 2)
        self.assertEqual(len(plan["route"]), 3)

    def test_none_free(self):
        self.assertIsNone(logistics.run(DONOR, NGOS[0], [{"id": 1, "name": "A", "lat": 0, "lng": 0, "available": 0}]))


class ForecastImpactTests(unittest.TestCase):
    def test_forecast_uses_same_weekday(self):
        monday = datetime(2026, 10, 5, 12)  # a Monday
        hist = [{"meals": 100, "created_at": monday.isoformat()},
                {"meals": 140, "created_at": (monday - timedelta(days=7)).isoformat()}]
        out = forecast.run(hist, datetime(2026, 10, 12))  # Monday; next day is Tuesday
        mon = next(r for r in out if r["weekday"] == "Monday")
        self.assertEqual(mon["expected_meals"], 120)
        self.assertEqual(len(out), 7)

    def test_impact_totals(self):
        s = impact.summarize([{"meals": 50, "kg": 20.0}, {"meals": 25, "kg": 10.0}])
        self.assertEqual(s["meals_rescued"], 75)
        self.assertEqual(s["kg_diverted"], 30.0)
        self.assertEqual(s["co2e_avoided_kg"], 75.0)

    def test_haversine(self):
        self.assertAlmostEqual(haversine_km(0, 0, 0, 1), 111.19, delta=0.5)


if __name__ == "__main__":
    unittest.main()
