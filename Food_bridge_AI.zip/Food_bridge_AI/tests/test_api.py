import os
import tempfile
import unittest

from app import create_app


class ApiTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.environ.pop("ANTHROPIC_API_KEY", None)  # keep tests offline and deterministic
        self.client = create_app(db_path=self.path).test_client()

    def tearDown(self):
        os.remove(self.path)

    def post(self, text, donor=1, storage="room"):
        return self.client.post("/api/listings", json={"donor_id": donor, "text": text, "storage": storage})

    def test_health_and_reference_data(self):
        self.assertEqual(self.client.get("/api/health").get_json()["status"], "ok")
        self.assertEqual(len(self.client.get("/api/donors").get_json()), 4)
        self.assertEqual(len(self.client.get("/api/ngos").get_json()), 4)

    def test_full_flow_matched_then_delivered(self):
        r = self.post("20 kg cooked rice and dal prepared 30 minutes ago")
        self.assertEqual(r.status_code, 201)
        body = r.get_json()
        self.assertEqual(body["status"], "matched")
        self.assertEqual([s["agent"] for s in body["trace"]],
                         ["Listing Agent", "Food Safety Agent", "Matching Agent", "Logistics Agent"])
        before = self.client.get("/api/dashboard").get_json()["impact"]["meals_rescued"]
        self.assertEqual(before, 0)
        d = self.client.post(f"/api/listings/{body['listing_id']}/deliver")
        self.assertEqual(d.get_json()["status"], "delivered")
        after = self.client.get("/api/dashboard").get_json()["impact"]["meals_rescued"]
        self.assertEqual(after - before, 50)

    def test_unsafe_food_rejected(self):
        body = self.post("20 kg cooked rice prepared 6 hours ago").get_json()
        self.assertEqual(body["status"], "rejected")
        self.assertEqual(len(body["trace"]), 2)  # stops after the safety agent

    def test_bad_input(self):
        self.assertEqual(self.post("some rice").status_code, 400)
        self.assertEqual(self.post("5 kg rice", donor=999).status_code, 404)
        self.assertEqual(self.client.post("/api/listings", json={}).status_code, 400)

    def test_cannot_deliver_twice(self):
        lid = self.post("10 kg cooked khichdi prepared now").get_json()["listing_id"]
        self.assertEqual(self.client.post(f"/api/listings/{lid}/deliver").status_code, 200)
        self.assertEqual(self.client.post(f"/api/listings/{lid}/deliver").status_code, 400)

    def test_volunteers_run_out(self):
        statuses = [self.post("5 kg cooked rice prepared now").get_json()["status"] for _ in range(4)]
        self.assertEqual(statuses.count("matched"), 3)  # 3 seeded volunteers
        self.assertEqual(statuses[-1], "unmatched")

    def test_forecast_and_donor_report(self):
        f = self.client.get("/api/forecast/1").get_json()
        self.assertEqual(len(f), 7)
        self.assertTrue(any(day["expected_meals"] > 0 for day in f))
        # fresh install: demo history feeds the forecast but is not counted as real impact
        self.assertEqual(self.client.get("/api/impact/1").get_json()["meals_rescued"], 0)
        lid = self.post("20 kg cooked rice prepared now").get_json()["listing_id"]
        self.client.post(f"/api/listings/{lid}/deliver")
        rep = self.client.get("/api/impact/1").get_json()
        self.assertEqual(rep["meals_rescued"], 50)
        self.assertEqual(rep["donor"], "Hotel Saurashtra Palace")
        self.assertEqual(self.client.get("/api/forecast/99").status_code, 404)


if __name__ == "__main__":
    unittest.main()
