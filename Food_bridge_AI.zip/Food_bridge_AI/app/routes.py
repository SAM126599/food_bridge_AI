import json
from datetime import datetime

from flask import Blueprint, jsonify, request

from .agents import forecast, impact, orchestrator
from .db import get_conn

bp = Blueprint("api", __name__, url_prefix="/api")


def _all(conn, sql, args=()):
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


@bp.errorhandler(ValueError)
def bad_request(err):
    return jsonify(error=str(err)), 400


@bp.errorhandler(LookupError)
def not_found(err):
    return jsonify(error=str(err)), 404


@bp.get("/health")
def health():
    return jsonify(status="ok", app="Food bridge AI")


@bp.get("/donors")
def donors():
    return jsonify(_all(get_conn(), "SELECT * FROM donors"))


@bp.get("/ngos")
def ngos():
    return jsonify(_all(get_conn(), "SELECT * FROM ngos"))


@bp.get("/volunteers")
def volunteers():
    return jsonify(_all(get_conn(), "SELECT * FROM volunteers"))


@bp.post("/listings")
def create_listing():
    body = request.get_json(silent=True) or {}
    if "donor_id" not in body:
        raise ValueError("donor_id is required")
    conn = get_conn()
    result = orchestrator.process_listing(conn, int(body["donor_id"]), body.get("text", ""),
                                          body.get("storage", "room"))
    return jsonify(result), 201


@bp.get("/listings")
def list_listings():
    conn = get_conn()
    rows = _all(conn, "SELECT l.*, d.name AS donor, n.name AS ngo, v.name AS volunteer FROM listings l "
                      "JOIN donors d ON d.id=l.donor_id LEFT JOIN ngos n ON n.id=l.ngo_id "
                      "LEFT JOIN volunteers v ON v.id=l.volunteer_id "
                      "WHERE l.raw_text != 'seed history' ORDER BY l.id DESC LIMIT 50")
    for r in rows:
        r["trace"] = json.loads(r["trace"] or "[]")
    return jsonify(rows)


@bp.post("/listings/<int:listing_id>/deliver")
def deliver(listing_id):
    return jsonify(orchestrator.mark_delivered(get_conn(), listing_id))


@bp.get("/dashboard")
def dashboard():
    conn = get_conn()
    # Seeded history exists only to feed the forecast, so it is not counted as real impact.
    delivered = _all(conn, "SELECT meals, kg FROM listings WHERE status='delivered' AND raw_text!='seed history'")
    counts = _all(conn, "SELECT status, COUNT(*) AS n FROM listings WHERE raw_text!='seed history' GROUP BY status")
    return jsonify(impact=impact.summarize(delivered), live_listings={c["status"]: c["n"] for c in counts})


@bp.get("/forecast/<int:donor_id>")
def forecast_donor(donor_id):
    conn = get_conn()
    if not conn.execute("SELECT 1 FROM donors WHERE id=?", (donor_id,)).fetchone():
        raise LookupError("Unknown donor")
    history = _all(conn, "SELECT meals, created_at FROM listings WHERE donor_id=? AND status='delivered'", (donor_id,))
    return jsonify(forecast.run(history, datetime.now()))


@bp.get("/impact/<int:donor_id>")
def donor_report(donor_id):
    """Per-donor impact / ESG summary."""
    conn = get_conn()
    donor = conn.execute("SELECT * FROM donors WHERE id=?", (donor_id,)).fetchone()
    if donor is None:
        raise LookupError("Unknown donor")
    rows = _all(conn, "SELECT meals, kg FROM listings WHERE donor_id=? AND status='delivered' "
                      "AND raw_text!='seed history'", (donor_id,))
    return jsonify(donor=donor["name"], **impact.summarize(rows))
