from math import asin, cos, radians, sin, sqrt

AVG_SPEED_KMH = 20.0  # city pickup speed assumption


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371.0
    dlat, dlng = radians(lat2 - lat1), radians(lng2 - lng1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlng / 2) ** 2
    return 2 * r * asin(sqrt(a))


def travel_minutes(km: float) -> float:
    return km / AVG_SPEED_KMH * 60
