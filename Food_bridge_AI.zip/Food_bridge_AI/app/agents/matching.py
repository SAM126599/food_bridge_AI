"""Matching agent: ranks NGOs by distance, need and time left."""
from .geo import haversine_km, travel_minutes

PICKUP_BUFFER_MIN = 20  # time to find a volunteer and load food


def run(listing: dict, donor: dict, ngos: list[dict], remaining_hours: float) -> dict:
    ranked = []
    for ngo in ngos:
        if listing["category"] not in ngo["accepts"].split(","):
            continue
        need_left = ngo["daily_need_meals"] - ngo["received_today"]
        if need_left <= 0:
            continue
        km = haversine_km(donor["lat"], donor["lng"], ngo["lat"], ngo["lng"])
        eta_min = travel_minutes(km) + PICKUP_BUFFER_MIN
        if eta_min / 60 > remaining_hours:
            continue  # cannot arrive inside the safe window
        proximity = 1 / (1 + km / 5)
        fit = min(listing["meals"], need_left) / listing["meals"]
        urgency = 1 - (eta_min / 60) / max(remaining_hours, 0.1)
        score = 0.4 * proximity + 0.4 * fit + 0.2 * urgency
        ranked.append({
            "ngo_id": ngo["id"], "name": ngo["name"], "distance_km": round(km, 2),
            "eta_min": round(eta_min), "need_left": need_left, "score": round(score, 3),
            "covers_all": need_left >= listing["meals"],
        })
    ranked.sort(key=lambda r: r["score"], reverse=True)
    return {"best": ranked[0] if ranked else None, "ranked": ranked}
