"""Logistics agent: nearest free volunteer and a two-leg route."""
from .geo import haversine_km, travel_minutes


def run(donor: dict, ngo: dict, volunteers: list[dict]) -> dict | None:
    free = [v for v in volunteers if v["available"]]
    if not free:
        return None
    best = min(free, key=lambda v: haversine_km(v["lat"], v["lng"], donor["lat"], donor["lng"]))
    leg1 = haversine_km(best["lat"], best["lng"], donor["lat"], donor["lng"])
    leg2 = haversine_km(donor["lat"], donor["lng"], ngo["lat"], ngo["lng"])
    return {
        "volunteer_id": best["id"],
        "volunteer": best["name"],
        "route": [
            {"stop": "Volunteer start", "lat": best["lat"], "lng": best["lng"]},
            {"stop": f"Pickup: {donor['name']}", "lat": donor["lat"], "lng": donor["lng"]},
            {"stop": f"Drop: {ngo['name']}", "lat": ngo["lat"], "lng": ngo["lng"]},
        ],
        "total_km": round(leg1 + leg2, 2),
        "eta_min": round(travel_minutes(leg1 + leg2)),
    }
