"""Coordinates the agents end to end and stores the result."""
import json
from datetime import datetime

from . import listing as listing_agent
from . import logistics, matching, safety


def _rows(conn, sql, args=()):
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def process_listing(conn, donor_id: int, text: str, storage: str = "room", now: datetime | None = None) -> dict:
    now = now or datetime.now()
    donor = conn.execute("SELECT * FROM donors WHERE id=?", (donor_id,)).fetchone()
    if donor is None:
        raise LookupError("Unknown donor")
    donor = dict(donor)
    trace = []

    # 1. Listing agent
    parsed = listing_agent.run(text, now)
    trace.append({"agent": "Listing Agent", "output": parsed})

    # 2. Food Safety agent
    check = safety.run(parsed, text, storage, now)
    trace.append({"agent": "Food Safety Agent", "output": check})

    status, ngo_id, volunteer_id, outcome = "rejected", None, None, {}
    if check["status"] != "reject":
        # 3. Matching agent
        ngos = _rows(conn, "SELECT * FROM ngos")
        match = matching.run(parsed, donor, ngos, check["remaining_hours"])
        trace.append({"agent": "Matching Agent", "output": match})
        if match["best"]:
            ngo = next(n for n in ngos if n["id"] == match["best"]["ngo_id"])
            # 4. Logistics agent
            plan = logistics.run(donor, ngo, _rows(conn, "SELECT * FROM volunteers"))
            trace.append({"agent": "Logistics Agent", "output": plan or {"error": "No volunteer free right now"}})
            if plan:
                status, ngo_id, volunteer_id = "matched", ngo["id"], plan["volunteer_id"]
                conn.execute("UPDATE volunteers SET available=0 WHERE id=?", (volunteer_id,))
                conn.execute("UPDATE ngos SET received_today=received_today+? WHERE id=?",
                             (parsed["meals"], ngo_id))
            else:
                status = "unmatched"
        else:
            status = "unmatched"

    cur = conn.execute(
        "INSERT INTO listings (donor_id, raw_text, food_type, category, kg, meals, prepared_at, safe_until,"
        " storage, status, ngo_id, volunteer_id, trace, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (donor_id, text, parsed["food_type"], parsed["category"], parsed["kg"], parsed["meals"],
         parsed["prepared_at"], check["safe_until"], check["storage"], status, ngo_id, volunteer_id,
         json.dumps(trace), now.isoformat()),
    )
    conn.commit()
    return {"listing_id": cur.lastrowid, "status": status, "trace": trace}


def mark_delivered(conn, listing_id: int, now: datetime | None = None) -> dict:
    now = now or datetime.now()
    row = conn.execute("SELECT * FROM listings WHERE id=?", (listing_id,)).fetchone()
    if row is None:
        raise LookupError("Unknown listing")
    if row["status"] != "matched":
        raise ValueError(f"Listing is '{row['status']}', only matched listings can be delivered.")
    conn.execute("UPDATE listings SET status='delivered', delivered_at=? WHERE id=?", (now.isoformat(), listing_id))
    conn.execute("UPDATE volunteers SET available=1 WHERE id=?", (row["volunteer_id"],))
    conn.commit()
    return {"listing_id": listing_id, "status": "delivered"}
