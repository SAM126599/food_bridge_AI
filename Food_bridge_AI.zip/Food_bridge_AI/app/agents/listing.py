"""Smart Surplus Listing agent: turns a donor's free text into a structured listing."""
import re
from datetime import datetime, timedelta

from . import llm

PORTIONS_PER_KG = 2.5  # ~400 g per meal (planning assumption)

CATEGORY_KEYWORDS = {
    "raw_meat_fish": ["raw chicken", "raw meat", "raw fish", "mutton raw", "raw egg"],
    "dairy": ["milk", "curd", "yogurt", "paneer", "cheese", "lassi", "buttermilk", "cream"],
    "bakery": ["bread", "bun", "cake", "pastry", "biscuit", "roti", "paratha", "pav", "cookie"],
    "fruit_veg": ["fruit", "vegetable", "veg ", "apple", "banana", "tomato", "potato", "salad", "onion", "mango"],
    "packaged": ["packaged", "packet", "sealed", "canned", "bottle", "chips", "juice box", "tetra"],
    "cooked": ["rice", "dal", "curry", "biryani", "sabzi", "khichdi", "cooked", "sambar", "pulao",
               "thali", "noodles", "pasta", "meal", "dinner", "lunch", "breakfast", "gravy", "idli", "dosa"],
}

UNIT_PORTIONS = r"(?:portions?|plates?|meals?|servings?|boxes|box|packets?|people|persons?)"


def classify_category(text: str) -> str:
    t = text.lower()
    for category in ("raw_meat_fish", "dairy", "bakery", "fruit_veg", "packaged", "cooked"):
        if any(k in t for k in CATEGORY_KEYWORDS[category]):
            return category
    return "other"


def parse_quantity(text: str) -> tuple[float | None, int | None]:
    t = text.lower()
    kg = None
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:kgs?|kilos?|kilograms?)\b", t)
    if m:
        kg = float(m.group(1))
    else:
        m = re.search(r"(\d+(?:\.\d+)?)\s*(?:g|grams?)\b", t)
        if m:
            kg = float(m.group(1)) / 1000
    portions = None
    m = re.search(rf"(\d+)\s*{UNIT_PORTIONS}\b", t)
    if m:
        portions = int(m.group(1))
    return kg, portions


def parse_prepared_at(text: str, now: datetime) -> datetime:
    t = text.lower()
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:hours?|hrs?|h)\s*ago", t)
    if m:
        return now - timedelta(hours=float(m.group(1)))
    m = re.search(r"(\d+)\s*(?:minutes?|mins?)\s*ago", t)
    if m:
        return now - timedelta(minutes=int(m.group(1)))
    m = re.search(r"(?:at|around|by)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)", t)
    if m:
        hour = int(m.group(1)) % 12 + (12 if m.group(3) == "pm" else 0)
        when = now.replace(hour=hour, minute=int(m.group(2) or 0), second=0, microsecond=0)
        return when - timedelta(days=1) if when > now else when
    return now  # assume just prepared


def run(text: str, now: datetime) -> dict:
    text = (text or "").strip()
    if not text:
        raise ValueError("Please describe the surplus food.")

    source = "rules"
    data = llm.extract(text)
    if data:
        source = "claude"
        category = data.get("category") or classify_category(text)
        kg, portions = data.get("kg"), data.get("portions")
        hours = data.get("hours_since_prepared")
        prepared_at = now - timedelta(hours=float(hours)) if hours is not None else parse_prepared_at(text, now)
        food_type = data.get("food_type") or text[:60]
    else:
        category = classify_category(text)
        kg, portions = parse_quantity(text)
        prepared_at = parse_prepared_at(text, now)
        food_type = text[:60]

    if kg is None and portions is None:
        raise ValueError("Could not find a quantity. Add something like '20 kg' or '50 portions'.")
    if portions is None:
        portions = max(1, round(kg * PORTIONS_PER_KG))
    if kg is None:
        kg = round(portions / PORTIONS_PER_KG, 1)

    return {
        "food_type": food_type,
        "category": category,
        "kg": round(float(kg), 1),
        "meals": int(portions),
        "prepared_at": prepared_at.isoformat(),
        "parsed_by": source,
    }
