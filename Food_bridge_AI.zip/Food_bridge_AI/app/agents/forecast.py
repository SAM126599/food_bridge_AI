"""Surplus Forecasting agent: expected meals per donor for the next 7 days.

Uses the average of past delivered listings on the same weekday, falling back
to the donor's overall daily average. A simple, explainable baseline.
"""
from collections import defaultdict
from datetime import datetime, timedelta


def run(history: list[dict], today: datetime) -> list[dict]:
    by_weekday, all_meals = defaultdict(list), []
    for row in history:
        when = datetime.fromisoformat(row["created_at"])
        by_weekday[when.weekday()].append(row["meals"])
        all_meals.append(row["meals"])
    overall = sum(all_meals) / len(all_meals) if all_meals else 0

    out = []
    for i in range(1, 8):
        day = today + timedelta(days=i)
        samples = by_weekday.get(day.weekday())
        if samples:
            predicted, basis = sum(samples) / len(samples), f"avg of {len(samples)} past {day.strftime('%A')}s"
        else:
            predicted, basis = overall * 0.2, "no listings on this weekday; low default"
        out.append({"date": day.date().isoformat(), "weekday": day.strftime("%A"),
                    "expected_meals": round(predicted), "basis": basis})
    return out
