"""Optional Claude-powered extraction. Returns None when unavailable so rules take over.

Enable with:  pip install anthropic   and   set ANTHROPIC_API_KEY
Optionally set FOODBRIDGE_MODEL to choose the model.
"""
import json
import os

PROMPT = (
    "Extract surplus-food details from the donor message. Reply with JSON only, keys: "
    'food_type (string), category (one of cooked, bakery, fruit_veg, dairy, packaged, raw_meat_fish, other), '
    "kg (number or null), portions (integer or null), hours_since_prepared (number or null). "
    "Message: "
)


def extract(text: str) -> dict | None:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return None
    try:
        import anthropic

        client = anthropic.Anthropic()
        msg = client.messages.create(
            model=os.environ.get("FOODBRIDGE_MODEL", "claude-sonnet-5-5"),
            max_tokens=300,
            messages=[{"role": "user", "content": PROMPT + text}],
        )
        raw = msg.content[0].text.strip()
        raw = raw[raw.find("{"): raw.rfind("}") + 1]
        return json.loads(raw)
    except Exception:  # network, key, parse errors: fall back to rules
        return None
