"""Food Safety agent.

Illustrative time limits only. Always confirm against FSSAI / local food-safety
guidance before using this in a real deployment.
"""
from datetime import datetime, timedelta

# hours the food stays acceptable after preparation: (room temperature, chilled)
SAFE_HOURS = {
    "cooked": (4, 24),
    "dairy": (2, 48),
    "bakery": (24, 72),
    "fruit_veg": (24, 96),
    "packaged": (720, 720),
    "raw_meat_fish": (2, 24),
    "other": (4, 24),
}

REJECT_PHRASES = ["leftover from plate", "half eaten", "half-eaten", "plate waste", "already served",
                  "smells", "sour", "spoiled", "expired", "mould", "mold", "rotten"]

MIN_USEFUL_HOURS = 1.0  # need time for pickup and delivery
CAUTION_HOURS = 2.0


def run(listing: dict, raw_text: str, storage: str, now: datetime) -> dict:
    storage = storage if storage in ("room", "chilled") else "room"
    flags = [p for p in REJECT_PHRASES if p in raw_text.lower()]
    room_h, chilled_h = SAFE_HOURS.get(listing["category"], SAFE_HOURS["other"])
    window = room_h if storage == "room" else chilled_h

    prepared = datetime.fromisoformat(listing["prepared_at"])
    safe_until = prepared + timedelta(hours=window)
    remaining = (safe_until - now).total_seconds() / 3600

    if flags:
        status, reason = "reject", f"Flagged wording: {', '.join(flags)}. Plate waste and spoiled food are not donated."
    elif listing["category"] == "raw_meat_fish" and storage == "room":
        status, reason = "reject", "Raw meat or fish must be kept chilled."
    elif remaining < MIN_USEFUL_HOURS:
        status, reason = "reject", f"Only {max(remaining, 0):.1f} h of safe time left; not enough to deliver."
    elif remaining < CAUTION_HOURS:
        status, reason = "caution", f"{remaining:.1f} h of safe time left. Needs a fast pickup."
    else:
        status, reason = "safe", f"{remaining:.1f} h of safe time left."

    return {
        "status": status,
        "reason": reason,
        "safe_until": safe_until.isoformat(),
        "remaining_hours": round(remaining, 2),
        "storage": storage,
        "checklist": ["Covered, clean containers", "Labelled with time prepared", "No plate waste mixed in"],
    }
