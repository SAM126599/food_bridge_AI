"""Impact numbers. Factors are planning assumptions; replace with audited ones."""

KG_PER_MEAL = 0.4
CO2E_KG_PER_KG_FOOD = 2.5  # rough lifecycle estimate for food diverted from waste


def summarize(delivered_rows: list[dict]) -> dict:
    meals = sum(r["meals"] for r in delivered_rows)
    kg = round(sum(r["kg"] for r in delivered_rows), 1)
    return {
        "deliveries": len(delivered_rows),
        "meals_rescued": meals,
        "kg_diverted": kg,
        "co2e_avoided_kg": round(kg * CO2E_KG_PER_KG_FOOD, 1),
        "assumptions": f"1 meal = {KG_PER_MEAL} kg; {CO2E_KG_PER_KG_FOOD} kg CO2e per kg food (estimates)",
    }
