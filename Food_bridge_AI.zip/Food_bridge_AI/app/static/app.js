const $ = (id) => document.getElementById(id);

// Build DOM with textContent only, so user text can never inject markup.
function el(tag, attrs = {}, ...kids) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v);
  }
  for (const kid of kids) node.append(kid instanceof Node ? kid : document.createTextNode(String(kid ?? "")));
  return node;
}

async function api(path, options) {
  const res = await fetch("/api" + path, options);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

function pill(status) { return el("span", { class: "pill " + status }, status); }

function renderStep(step) {
  const out = step.output || {};
  const box = el("div", { class: "step" }, el("h3", {}, step.agent));
  const dl = el("dl");
  const add = (k, v) => { dl.append(el("dt", {}, k), el("dd", {}, v)); };
  switch (step.agent) {
    case "Listing Agent":
      add("Food", `${out.food_type} (${out.category})`);
      add("Quantity", `${out.kg} kg, about ${out.meals} meals`);
      add("Parsed by", out.parsed_by);
      break;
    case "Food Safety Agent":
      box.querySelector("h3").append(" ", pill(out.status));
      add("Why", out.reason);
      add("Safe until", new Date(out.safe_until).toLocaleString());
      add("Donor checklist", out.checklist.join("; "));
      break;
    case "Matching Agent":
      if (out.best) {
        add("Best NGO", out.best.name);
        add("Distance", `${out.best.distance_km} km, ETA ${out.best.eta_min} min`);
        add("Need left today", `${out.best.need_left} meals`);
        add("Other options", out.ranked.slice(1).map((r) => r.name).join(", ") || "none");
      } else add("Result", "No NGO can take this in time.");
      break;
    case "Logistics Agent":
      if (out.error) add("Result", out.error);
      else {
        add("Volunteer", out.volunteer);
        add("Route", out.route.map((r) => r.stop).join("  ->  "));
        add("Total", `${out.total_km} km, about ${out.eta_min} min`);
      }
      break;
  }
  box.append(dl);
  return box;
}

async function loadStats() {
  const d = await api("/dashboard");
  $("s-meals").textContent = d.impact.meals_rescued;
  $("s-kg").textContent = d.impact.kg_diverted;
  $("s-co2").textContent = d.impact.co2e_avoided_kg;
  const live = (d.live_listings.matched || 0) + (d.live_listings.unmatched || 0);
  $("s-live").textContent = live;
}

async function loadListings() {
  const rows = await api("/listings");
  const body = $("listings").querySelector("tbody");
  body.replaceChildren(...rows.map((r) => el("tr", {},
    el("td", {}, r.id), el("td", {}, r.donor), el("td", {}, `${r.category}, ${r.kg} kg`), el("td", {}, r.meals),
    el("td", {}, pill(r.status)), el("td", {}, r.ngo || "-"), el("td", {}, r.volunteer || "-"),
    el("td", {}, r.status === "matched"
      ? el("button", { class: "small", onclick: () => deliver(r.id) }, "Mark delivered") : ""))));
}

async function loadForecast() {
  const rows = await api(`/forecast/${$("donor").value}`);
  $("forecast").querySelector("tbody").replaceChildren(...rows.map((r) => el("tr", {},
    el("td", {}, r.date), el("td", {}, r.weekday), el("td", {}, r.expected_meals), el("td", {}, r.basis))));
}

async function deliver(id) {
  await api(`/listings/${id}/deliver`, { method: "POST" });
  await refresh();
}

async function refresh() { await Promise.all([loadStats(), loadListings(), loadForecast()]); }

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("error").hidden = true;
  try {
    const result = await api("/listings", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ donor_id: Number($("donor").value), text: $("text").value, storage: $("storage").value }),
    });
    $("trace").replaceChildren(...result.trace.map(renderStep),
      el("div", { class: "step" }, el("h3", {}, "Outcome"), pill(result.status)));
    $("result").hidden = false;
    await refresh();
  } catch (err) {
    $("error").textContent = err.message;
    $("error").hidden = false;
  }
});

$("donor").addEventListener("change", loadForecast);

(async () => {
  const donors = await api("/donors");
  $("donor").replaceChildren(...donors.map((d) => el("option", { value: d.id }, `${d.name} (${d.kind})`)));
  await refresh();
})();
