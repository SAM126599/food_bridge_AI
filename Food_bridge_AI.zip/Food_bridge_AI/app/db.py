"""SQLite storage and demo seed data."""
import sqlite3
from datetime import datetime, timedelta

from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS donors (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL,
  lat REAL NOT NULL, lng REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS ngos (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL,
  daily_need_meals INTEGER NOT NULL,      -- meals this receiver can use per day
  received_today INTEGER NOT NULL DEFAULT 0,
  accepts TEXT NOT NULL                    -- comma separated food categories
);
CREATE TABLE IF NOT EXISTS volunteers (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL,
  available INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS listings (
  id INTEGER PRIMARY KEY AUTOINCREMENT, donor_id INTEGER NOT NULL,
  raw_text TEXT NOT NULL, food_type TEXT, category TEXT, kg REAL, meals INTEGER,
  prepared_at TEXT, safe_until TEXT, storage TEXT,
  status TEXT NOT NULL,                    -- matched | rejected | unmatched | delivered
  ngo_id INTEGER, volunteer_id INTEGER, trace TEXT,
  created_at TEXT NOT NULL, delivered_at TEXT
);
"""


def get_conn() -> sqlite3.Connection:
    """One connection per request, closed automatically by close_conn()."""
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DB_PATH"])
        g.db.row_factory = sqlite3.Row
    return g.db


def close_conn(_exc=None) -> None:
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db(path: str, seed: bool = True) -> None:
    conn = sqlite3.connect(path)
    conn.executescript(SCHEMA)
    if seed and conn.execute("SELECT COUNT(*) FROM donors").fetchone()[0] == 0:
        seed_demo(conn)
    conn.commit()
    conn.close()


def seed_demo(conn: sqlite3.Connection) -> None:
    """Demo data around Rajkot, Gujarat (illustrative coordinates)."""
    donors = [
        (1, "Hotel Saurashtra Palace", "hotel", 22.3039, 70.8022),
        (2, "Marwadi University Canteen", "canteen", 22.2587, 70.7739),
        (3, "Shree Caterers", "caterer", 22.2950, 70.7900),
        (4, "Green Leaf Restaurant", "restaurant", 22.3150, 70.7800),
    ]
    ngos = [
        (1, "Annapurna Community Kitchen", 22.3000, 70.7850, 300, 0, "cooked,bakery,fruit_veg,packaged,other"),
        (2, "Seva Old Age Home", 22.3200, 70.8100, 120, 0, "cooked,bakery,fruit_veg,dairy,other"),
        (3, "Bal Ashray Shelter", 22.2700, 70.7600, 200, 0, "cooked,bakery,packaged,fruit_veg,dairy,other"),
        (4, "City Food Bank", 22.2900, 70.8300, 500, 0, "packaged,fruit_veg,bakery"),
    ]
    volunteers = [
        (1, "Aarav (student volunteer)", 22.3010, 70.7950, 1),
        (2, "Diya (NSS unit)", 22.2650, 70.7700, 1),
        (3, "Kabir (delivery partner)", 22.3100, 70.8000, 1),
    ]
    conn.executemany("INSERT INTO donors VALUES (?,?,?,?,?)", donors)
    conn.executemany("INSERT INTO ngos VALUES (?,?,?,?,?,?,?)", ngos)
    conn.executemany("INSERT INTO volunteers VALUES (?,?,?,?,?)", volunteers)

    # Four weeks of delivered history so the forecasting agent has data.
    now = datetime.now().replace(minute=0, second=0, microsecond=0)
    base_meals = {1: 80, 2: 120, 3: 150, 4: 40}
    for week in range(1, 5):
        for donor_id, base in base_meals.items():
            for day in (0, 2, 4, 5):  # donors list on four weekdays
                when = now - timedelta(days=week * 7 - day)
                meals = int(base * (1 + 0.15 * (day == 5)) + week * 2)
                conn.execute(
                    "INSERT INTO listings (donor_id, raw_text, food_type, category, kg, meals, prepared_at,"
                    " safe_until, storage, status, ngo_id, volunteer_id, trace, created_at, delivered_at)"
                    " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (donor_id, "seed history", "cooked food", "cooked", round(meals / 2.5, 1), meals,
                     when.isoformat(), (when + timedelta(hours=4)).isoformat(), "room", "delivered",
                     1, 1, "[]", when.isoformat(), (when + timedelta(hours=1)).isoformat()),
                )
