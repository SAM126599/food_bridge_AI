import os

from flask import Flask

from . import db
from .routes import bp


def _default_db_path(filename: str) -> str:
    """Next to the project locally. Vercel's filesystem is read-only except /tmp."""
    if os.environ.get("VERCEL"):
        return os.path.join("/tmp", filename)
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), filename)


def create_app(db_path: str | None = None, seed: bool = True) -> Flask:
    """Application factory. Pass db_path=':memory:' style paths for tests."""
    app = Flask(__name__, static_folder="static", static_url_path="")
    app.config["DB_PATH"] = db_path or os.environ.get(
        "FOODBRIDGE_DB", _default_db_path("foodbridge.db")
    )
    with app.app_context():
        db.init_db(app.config["DB_PATH"], seed=seed)
    app.teardown_appcontext(db.close_conn)
    app.register_blueprint(bp)

    @app.get("/")
    def index():
        return app.send_static_file("index.html")

    return app
