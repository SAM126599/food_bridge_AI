# Food bridge AI

Turn today's surplus food into tomorrow's meals. **SDG 2 - Zero Hunger** (food wastage).

A donor (hotel, caterer, canteen) describes leftover food in plain text. A team of agents
checks it, finds the best NGO, assigns a volunteer and reports the impact.

```
Donor text -> Listing Agent -> Food Safety Agent -> Matching Agent -> Logistics Agent -> Impact
                                                                        (Forecast Agent plans ahead)
```

## Run it on your laptop

Requires Python 3.10+.

```bash
cd Food_bridge_AI
python -m venv .venv
# Windows:  .venv\Scripts\activate        macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

Open http://127.0.0.1:5000 . Demo donors, NGOs and volunteers (around Rajkot) are seeded
automatically into `foodbridge.db`. Delete that file to reset.

Run the tests (no extra packages needed):

```bash
python -m unittest discover -s tests -v
```

## Try these inputs

| Input | Expected result |
|---|---|
| `20 kg cooked rice and dal prepared 1 hour ago` | safe, matched to an NGO, volunteer assigned |
| `50 portions biryani cooked 30 minutes ago` | matched |
| `20 kg cooked rice prepared 6 hours ago` | rejected by the Food Safety Agent |
| `half eaten plates of dal 5 kg` | rejected (plate waste) |
| `10 kg bread and buns prepared at 8 am` | bakery has a long window, matched |

After a match, click **Mark delivered** to add it to the impact counters.

## Project layout

```
run.py                       start the server
app/__init__.py              Flask app factory
app/db.py                    SQLite schema and demo seed data
app/routes.py                JSON API
app/agents/listing.py        free text -> food type, quantity, prepared time
app/agents/safety.py         safe-window check (safe / caution / reject)
app/agents/matching.py       rank NGOs by distance, need and time left
app/agents/logistics.py      nearest free volunteer and route
app/agents/forecast.py       expected meals per donor for the next 7 days
app/agents/impact.py         meals, kg and CO2e totals
app/agents/orchestrator.py   runs the agents in order and stores the result
app/agents/llm.py            optional Claude parser
app/static/                  web UI (index.html, app.js, style.css)
tests/                       unit and API tests
```

## API

| Method and path | Purpose |
|---|---|
| `POST /api/listings` | `{donor_id, text, storage}` runs all agents |
| `GET /api/listings` | recent listings with the agent trace |
| `POST /api/listings/<id>/deliver` | mark a matched listing delivered |
| `GET /api/dashboard` | meals rescued, kg diverted, CO2e avoided |
| `GET /api/forecast/<donor_id>` | 7 day surplus forecast |
| `GET /api/impact/<donor_id>` | donor level impact report |
| `GET /api/donors`, `/api/ngos`, `/api/volunteers` | reference data |

Example:

```bash
curl -X POST http://127.0.0.1:5000/api/listings \
  -H "Content-Type: application/json" \
  -d '{"donor_id":1,"text":"20 kg cooked rice and dal prepared 1 hour ago","storage":"room"}'
```

## Optional: Claude-powered parsing

By default the Listing Agent uses rules (regex and keywords). To let Claude read messier
text:

```bash
pip install anthropic
export ANTHROPIC_API_KEY=your_key      # Windows: set ANTHROPIC_API_KEY=your_key
export FOODBRIDGE_MODEL=claude-sonnet-5-5   # optional
```

If the key, package or network is missing, it falls back to the rules automatically.

## Assumptions to review

- Safe-time limits in `safety.py` are illustrative. Check them against FSSAI or local
  guidance before any real use.
- 1 meal = 0.4 kg and 2.5 kg CO2e per kg of food are planning estimates (`impact.py`).
- Travel speed is 20 km/h straight-line distance (`geo.py`).
- The forecast is a same-weekday average, a baseline you can replace with a real model.
- The seed history is made-up demo data. It only feeds the forecast and is not counted in
  the impact numbers, which start at zero and grow as you mark deliveries.

## Ideas to extend

WhatsApp bot (Twilio or Meta Cloud API) for listings, image input, real map routing,
login for donors and NGOs, a database such as PostgreSQL.
