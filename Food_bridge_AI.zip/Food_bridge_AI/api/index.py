"""Vercel entry point: Vercel looks for a WSGI object called `app` in api/index.py."""
import os
import sys

# Make the project root importable no matter where Vercel starts the function from.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402

app = create_app()
